// Crear un objeto
var persona = {
    // propiedades y valores del objeto
    nombre: 'Pepe',
    edad: 37,
    aficiones: ['cine', 'musica']
}; // las llaves indican que es un objeto
// Puedo asignar otros valores al objeto pero las propiedades deben ser las mismas
persona = {
    nombre: 'Pepe',
    edad: 38,
    aficiones: ['cine', 'musica', 'futbol']
};
console.log(persona);
// Crear el objeto con tipos de datos especificos
var persona2 = {
    nombre: 'Luis',
    edad: 29,
    aficiones: ['senderismo', 'teatro']
};
console.log(persona2);
// Crear metodos dentro del objeto
var persona3 = {
    nombre: 'Jose',
    edad: 51,
    aficiones: ['natacion', 'cine', 'pintura'],
    getNombre: function () {
        return this.nombre;
    }
};
console.log(persona3);
console.log("Nombre: " + persona3.getNombre());
var maria = {
    nombre: "Maria",
    edad: 39,
    aficiones: ['danza', 'opera'],
    getNombre: function () {
        return this.nombre;
    }
};
// Crear una variable con multiples tipos
var variable;
variable = "Hola";
variable = 6789;
variable = {
    nombre: 'Jose',
    edad: 51,
    aficiones: ['natacion', 'cine', 'pintura'],
    getNombre: function () {
        return this.nombre;
    }
};
