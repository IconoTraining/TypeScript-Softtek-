// Crear un objeto
let persona: object = {
    // propiedades y valores del objeto
    nombre: 'Pepe',
    edad: 37,
    aficiones: ['cine', 'musica']
};  // las llaves indican que es un objeto

// Puedo asignar otros valores al objeto pero las propiedades deben ser las mismas
persona = {
    nombre: 'Pepe',
    edad: 38,
    aficiones: ['cine', 'musica', 'futbol']
};
console.log(persona);

// Crear el objeto con tipos de datos especificos
let persona2: {nombre: string, edad: number, aficiones: string[]} = {
    nombre: 'Luis',
    edad: 29,
    aficiones: ['senderismo', 'teatro']
};
console.log(persona2);

// Crear metodos dentro del objeto
let persona3: {nombre: string, edad: number, aficiones: string[], getNombre:()=>string} = {
    nombre: 'Jose',
    edad: 51,
    aficiones: ['natacion', 'cine', 'pintura'],
    getNombre(): string{
        return this.nombre;
    }
};
console.log(persona3);
console.log("Nombre: " + persona3.getNombre());


// Crear el tipo Persona y posteriormente crear los objetos
type Persona = {
    nombre: string, 
    edad: number, 
    aficiones: string[], 
    getNombre:()=>string
}

let maria: Persona = {
    nombre: "Maria",
    edad: 39,
    aficiones: ['danza', 'opera'],
    getNombre(): string {
        return this.nombre
    },
}

// Crear una variable con multiples tipos
let variable: string | number | Persona;
variable = "Hola";
variable = 6789;
variable = {
    nombre: 'Jose',
    edad: 51,
    aficiones: ['natacion', 'cine', 'pintura'],
    getNombre(): string{
        return this.nombre;
    }
}