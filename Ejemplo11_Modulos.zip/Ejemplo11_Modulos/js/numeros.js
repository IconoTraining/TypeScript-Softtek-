export function redondeoBaja(numero) {
    return Math.floor(numero);
}
export function redondeoMedio(numero) {
    return Math.round(numero);
}
export function redondeoAlto(numero) {
    return Math.ceil(numero);
}
