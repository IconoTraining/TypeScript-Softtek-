import * as Textos from './textos.js';
import { redondeoMedio } from './numeros.js';
import { Persona } from './persona.js';

console.log(Textos.longitud("Hola, que tal?"));
console.log(Textos.mayusculas("Ejemplo de texto en mayusculas"));
console.log(Textos.minusculas("Ejemplo de texto en minusculas"));

console.log("4.78: " + redondeoMedio(4.78));
console.log("4.18: " + redondeoMedio(4.18));

let juan: Persona = new Persona("Juan", 45);
console.log(juan.mostrar());