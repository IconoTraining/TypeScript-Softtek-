export function longitud(texto: string): number{
    return texto.length;
}

export function mayusculas(texto: string): string{
    return texto.toUpperCase();
}

export function minusculas(texto: string): string{
    return texto.toLowerCase();
}