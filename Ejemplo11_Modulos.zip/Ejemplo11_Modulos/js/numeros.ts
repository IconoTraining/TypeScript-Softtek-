export function redondeoBaja(numero:number): number{
    return Math.floor(numero);
}

export function redondeoMedio(numero:number): number{
    return Math.round(numero);
}

export function redondeoAlto(numero:number): number{
    return Math.ceil(numero);
}