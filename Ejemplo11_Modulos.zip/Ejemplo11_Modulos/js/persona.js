export class Persona {
    constructor(nombre, edad) {
        this.nombre = nombre;
        this.edad = edad;
    }
    mostrar() {
        return `Nombre: ${this.nombre}, Edad: ${this.edad}`;
    }
}
