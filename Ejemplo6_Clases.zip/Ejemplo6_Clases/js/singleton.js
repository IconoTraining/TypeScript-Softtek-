// Crear una clase que solo pueda haber una instancia de ella
var Contabilidad = /** @class */ (function () {
    function Contabilidad() {
        this.asientos = [];
    }
    Contabilidad.getInstancia = function () {
        // Si no tengo una instancia de contabilidad
        if (!Contabilidad.instancia) {
            // la creo
            Contabilidad.instancia = new Contabilidad();
        }
        return Contabilidad.instancia;
    };
    Contabilidad.prototype.anotarAsiento = function (concepto) {
        this.asientos.push(concepto);
    };
    return Contabilidad;
}());
// let libro1: Contabilidad = new Contabilidad();  El constructor es privado 
var libro1 = Contabilidad.getInstancia();
libro1.anotarAsiento("Compra material por valor de 200€");
// Puedo pedir el libro de contabilidad tantas veces como quiera pero
// siempre me devuelve la misma instancia
var libro2 = Contabilidad.getInstancia();
libro2.anotarAsiento("Amortizacion de maquinaria por valor de 6000€");
// Por eso, todos los asientos que yo hago van al mismo array,
// porque al haber una sola instancia solo hay una copia del array
for (var _i = 0, _a = libro1.asientos; _i < _a.length; _i++) {
    var asiento = _a[_i];
    console.log(asiento);
}
