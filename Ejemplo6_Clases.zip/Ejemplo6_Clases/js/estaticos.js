// Los recursos (propiedades y metodos) estaticos, solo Existe una copia
// y reside en la clase
var Producto = /** @class */ (function () {
    function Producto(id, descripcion, precio) {
        this.id = id;
        this.descripcion = descripcion;
        this.precio = precio;
        // cada vez que genero un  nuevo objeto incremento el contador
        Producto.contador++;
    }
    Producto.getContador = function () {
        return Producto.contador;
    };
    // propiedad de clase -> solo existe una copia y reside en la clase
    Producto.contador = 0;
    return Producto;
}());
// la forma correcta de invocar un recurso estatico: Clase.recurso
var producto1 = new Producto(1, "Pantalla", 149.50);
console.log("Contador: " + Producto.contador);
var producto2 = new Producto(2, "Teclado", 49.95);
console.log("Contador: " + Producto.contador);
console.log("Contador actual: " + Producto.getContador());
console.log(producto1);
console.log(producto2);
