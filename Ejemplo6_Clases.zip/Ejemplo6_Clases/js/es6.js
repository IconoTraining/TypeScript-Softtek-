/*
    Clases en ES6
*/
class Persona{
    constructor (nombre, edad){
        this.nombre = nombre;
        this.edad = edad;
    }
}

class Empleado extends Persona{
    constructor(nombre, edad, sueldo){
        super(nombre, edad);
        this.sueldo = sueldo;
    }
}

let persona = new Persona("Jose", 49);
let empleado = new Empleado("Elena", 38, 40000);

console.log(persona);
console.log(empleado);