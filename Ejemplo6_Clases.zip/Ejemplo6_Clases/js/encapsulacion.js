var FechaNoEncapsulada = /** @class */ (function () {
    function FechaNoEncapsulada(dia, mes, anyo) {
        this.dia = dia;
        this.mes = mes;
        this.anyo = anyo;
    }
    FechaNoEncapsulada.prototype.mostrar = function () {
        return "".concat(this.dia, "/").concat(this.mes, "/").concat(this.anyo);
    };
    return FechaNoEncapsulada;
}());
// Una clase encapsulada, define todas las propiedades como privadas
// y solo se accede a ellas a través de los métodos get y set publicos
var Fecha = /** @class */ (function () {
    function Fecha(dia, mes, anyo) {
        this.dia = dia;
        this.mes = mes;
        this.anyo = anyo;
    }
    Fecha.prototype.mostrar = function () {
        return "".concat(this._dia, "/").concat(this._mes, "/").concat(this._anyo);
    };
    Object.defineProperty(Fecha.prototype, "dia", {
        get: function () {
            return this._dia;
        },
        set: function (dia) {
            if (dia > 0 && dia <= 30) {
                this._dia = dia;
            }
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Fecha.prototype, "mes", {
        get: function () {
            return this._mes;
        },
        set: function (mes) {
            if (mes > 0 && mes <= 12) {
                this._mes = mes;
            }
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Fecha.prototype, "anyo", {
        get: function () {
            return this._anyo;
        },
        set: function (anyo) {
            if (anyo == 2023 || anyo == 2024 || anyo == 23 || anyo == 24) {
                this._anyo = anyo;
            }
        },
        enumerable: false,
        configurable: true
    });
    return Fecha;
}());
var hoy = new FechaNoEncapsulada(-6778, 123.78, 0);
console.log(hoy.mostrar());
var fecha = new Fecha(-6778, 123.78, 0);
console.log(fecha.mostrar());
var fechaBuena = new Fecha(21, 3, 23);
console.log(fechaBuena.mostrar());
