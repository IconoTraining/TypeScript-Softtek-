var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
/*
    Clases en TypeScript
*/
var Persona2 = /** @class */ (function () {
    function Persona2(nombre, edad) {
        this.nombre = nombre;
        this.edad = edad;
    }
    return Persona2;
}());
var Empleado2 = /** @class */ (function (_super) {
    __extends(Empleado2, _super);
    function Empleado2(nombre, edad, sueldo) {
        var _this = _super.call(this, nombre, edad) || this;
        _this._sueldo = sueldo;
        return _this;
    }
    Object.defineProperty(Empleado2.prototype, "sueldo", {
        // get clasico
        /*public getSueldo(): number{
            return this.sueldo;
        }*/
        // Otra forma de declarar los metodos get
        get: function () {
            return this._sueldo;
        },
        enumerable: false,
        configurable: true
    });
    Empleado2.prototype.mostrar = function () {
        return "Me llamo ".concat(this.nombre, " y tengo ").concat(this.edad, " a\u00F1os");
    };
    return Empleado2;
}(Persona2));
var persona2 = new Persona2("Jose", 49);
var empleado2 = new Empleado2("Elena", 38, 40000);
console.log(persona2);
console.log(empleado2);
console.log("Sueldo: " + empleado2.sueldo); // internamente llama al metodo get
//  empleado2.sueldo = 50000;  Es privado no es accesible
// console.log("Edad: " + empleado2.edad);  Edad es protected
console.log("Nombre: " + empleado2.nombre); // Es publico
// Modo de acceso para propiedades y metodos:
// public -> es accesible desde cualquier parte del script
// protected -> solo es accesible desde la propia clase y sus subclases
// private -> solo es accesible desde dentro de la clase
