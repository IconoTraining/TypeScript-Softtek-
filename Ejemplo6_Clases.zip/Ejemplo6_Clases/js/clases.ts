/*
    Clases en TypeScript
*/
class Persona2{

    // Es necesario declarar las propiedades
    nombre: string;
    protected edad: number;

    constructor (nombre: string, edad: number){
        this.nombre = nombre;
        this.edad = edad;
    }
}

class Empleado2 extends Persona2{

    private _sueldo: number;

    constructor(nombre: string , edad: number, sueldo: number){
        super(nombre, edad);
        this._sueldo = sueldo;
    }

    // get clasico
    /*public getSueldo(): number{
        return this.sueldo;
    }*/

    // Otra forma de declarar los metodos get
    public get sueldo(): number{
        return this._sueldo;
    }

    public mostrar(): string{
        return `Me llamo ${this.nombre} y tengo ${this.edad} años`;
    }
}

let persona2: Persona2 = new Persona2("Jose", 49);
let empleado2: Empleado2 = new Empleado2("Elena", 38, 40000);

console.log(persona2);
console.log(empleado2);
console.log("Sueldo: " + empleado2.sueldo);  // internamente llama al metodo get
//  empleado2.sueldo = 50000;  Es privado no es accesible

// console.log("Edad: " + empleado2.edad);  Edad es protected
console.log("Nombre: " + empleado2.nombre);  // Es publico


// Modo de acceso para propiedades y metodos:
// public -> es accesible desde cualquier parte del script
// protected -> solo es accesible desde la propia clase y sus subclases
// private -> solo es accesible desde dentro de la clase