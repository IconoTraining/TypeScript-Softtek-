// Una clase abstracta es una clase inacabada.
// Tiene metodos abstractos sin implementar
abstract class Persona{

    nombre: string;
    edad: number;

    constructor(nombre:string, edad: number){
        this.nombre = nombre;
        this.edad = edad;
    }

    // Metodo declarado pero no implementado
    abstract mostrar(): string;
}

class Amigo extends Persona{
    mostrar(): string{
        return `Hola ${this.nombre} que pasa tio?`;
    }
}

class Profesional extends Persona{
    mostrar(): string{
        return `Buenos dias ${this.nombre}, como estas?`;
    }
}

// Yo no puedo instanciar una clase abstracta
// let persona: Persona = new Persona("Maria", 29);

let amigo: Persona = new Amigo("Jose", 52);
let profesional: Persona = new Profesional("Daniel", 42);
console.log(amigo.mostrar());
console.log(profesional.mostrar());