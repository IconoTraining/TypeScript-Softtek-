// Crear una clase que solo pueda haber una instancia de ella

class Contabilidad{

    // propiedad que almacene la unica instancia
    private static instancia: Contabilidad;
    asientos: Array<string> = []; 

    private constructor(){}

    static getInstancia(): Contabilidad{
        // Si no tengo una instancia de contabilidad
        if (!Contabilidad.instancia){
            // la creo
            Contabilidad.instancia = new Contabilidad();
        }
        return Contabilidad.instancia;
    }

    anotarAsiento(concepto: string): void{
        this.asientos.push(concepto);
    }
}

// let libro1: Contabilidad = new Contabilidad();  El constructor es privado 
let libro1: Contabilidad = Contabilidad.getInstancia();
libro1.anotarAsiento("Compra material por valor de 200€");

// Puedo pedir el libro de contabilidad tantas veces como quiera pero
// siempre me devuelve la misma instancia
let libro2: Contabilidad = Contabilidad.getInstancia();
libro2.anotarAsiento("Amortizacion de maquinaria por valor de 6000€");

// Por eso, todos los asientos que yo hago van al mismo array,
// porque al haber una sola instancia solo hay una copia del array
for(let asiento of libro1.asientos){
    console.log(asiento);
}

