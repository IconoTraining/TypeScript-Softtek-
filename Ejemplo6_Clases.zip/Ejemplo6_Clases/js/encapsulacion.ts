class FechaNoEncapsulada{
    public dia: number;
    public mes: number;
    public anyo: number;

    constructor(dia: number, mes: number, anyo: number){
        this.dia = dia;
        this.mes = mes;
        this.anyo = anyo;
    }

    mostrar(){
        return `${this.dia}/${this.mes}/${this.anyo}`;
    }
}

// Una clase encapsulada, define todas las propiedades como privadas
// y solo se accede a ellas a través de los métodos get y set publicos
class Fecha{
    private _dia: number;
    private _mes: number;
    private _anyo: number;

    constructor(dia: number, mes: number, anyo: number){
        this.dia = dia;
        this.mes = mes;
        this.anyo = anyo;
    }

    mostrar(){
        return `${this._dia}/${this._mes}/${this._anyo}`;
    }

    get dia(): number{
        return this._dia;
    }

    set dia(dia: number){
        if (dia > 0 && dia <= 30){
            this._dia = dia;
        }
    }

    get mes(): number{
        return this._mes;
    }

    set mes(mes: number){
        if (mes > 0 && mes <= 12){
            this._mes = mes;
        }
    }

    get anyo(): number{
        return this._anyo;
    }

    set anyo(anyo: number){
        if (anyo == 2023 || anyo == 2024 || anyo == 23 || anyo == 24){
            this._anyo = anyo;
        }
    }
}

let hoy: FechaNoEncapsulada = new FechaNoEncapsulada(-6778,123.78,0);
console.log(hoy.mostrar());

let fecha: Fecha = new Fecha(-6778,123.78,0);
console.log(fecha.mostrar());

let fechaBuena: Fecha = new Fecha(21,3,23);
console.log(fechaBuena.mostrar());