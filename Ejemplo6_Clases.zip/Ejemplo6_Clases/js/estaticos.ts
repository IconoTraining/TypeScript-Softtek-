// Los recursos (propiedades y metodos) estaticos, solo Existe una copia
// y reside en la clase

class Producto{

    // propiedades de instancia -> cada instancia tiene una copia de estas propiedades
    id: number;
    descripcion: string;
    precio: number;

    // propiedad de clase -> solo existe una copia y reside en la clase
    static contador: number = 0;

    constructor(id: number, descripcion: string, precio: number){
        this.id = id;
        this.descripcion = descripcion;
        this.precio = precio;

        // cada vez que genero un  nuevo objeto incremento el contador
        Producto.contador++;
    }

    static getContador(): number{
        return Producto.contador;
    }
}

// la forma correcta de invocar un recurso estatico: Clase.recurso

let producto1: Producto = new Producto(1, "Pantalla", 149.50);
console.log("Contador: " + Producto.contador);
let producto2: Producto = new Producto(2, "Teclado", 49.95);
console.log("Contador: " + Producto.contador);

console.log("Contador actual: " + Producto.getContador());

console.log(producto1);
console.log(producto2);