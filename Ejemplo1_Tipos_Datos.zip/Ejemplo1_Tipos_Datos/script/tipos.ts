// boolean
let soltero: boolean = true;
let trabajador: boolean;   // undefined
let activo = true;   // No se recomienda declarar variables sin tipo


// number
let edad: number = 37;
let decimal: number = 6.2;
let hexadecimal: number = 0xfe124455;
let binario: number = 0b11001010;
let octal: number = 0o4327;


// string
let nombre: string = "Anabel";
let apellido: string = 'Vegas';
let email: string;    // undefined
let nombreCompleto: string = `Me llamo ${nombre} ${apellido}`;
console.log(nombreCompleto);


// any 
let algo: any = true;
algo = "Hola";
algo = 56;
let variable;   // las variables sin tipo son de tipo any


// arrays
let numeros = [1,2,3,4,5,6];
let numeros2: number[] = [1,2,3,4,5,6];
let numeros3: Array<number> = [1,2,3,4,5,6];
let vocales: string[] = ['a', 'e', 'i', 'o', 'u'];
// vocales.push(7);    error, no puedo agregar un numero a un array de texto


// tuplas
let producto = ["Melocotones", 2.75];
let producto2: [string, number] = ["Melocotones", 2.75];
console.log("Fruta: " + producto2[0]);
console.log("Precio: " + producto2[1]);


// enum
//enum PuntoCardinal{NORTE, SUR, ESTE, OESTE};
//enum PuntoCardinal{NORTE=1, SUR, ESTE, OESTE};
enum PuntoCardinal{NORTE=2, SUR=4, ESTE=6, OESTE=8};
let punto: PuntoCardinal = PuntoCardinal.OESTE;
console.log(punto);
console.log(PuntoCardinal[6]);  // ESTE
console.log(PuntoCardinal[5]);  // undefined


// void
function mostrarInfo(): void{
    alert(`Hola, me llamo ${nombre} ${apellido} y tengo ${edad}`);
}
mostrarInfo();


// aserciones -> assertion
let num1: unknown = 5;
let num2: unknown = 6;
// let suma2: number = num1 + num2;   error
let suma: number = (<number>num1) + (num2 as number);
console.log(suma);

let cadena: unknown = "Hola, que tal?";
// let longitud = cadena.length;    ERROR
//let longitud: number = (<string>cadena).length;
let longitud: number = (cadena as string).length;
console.log(longitud);


// null y undefined
// en tsconfig.json   ->   "strictNullChecks": false
let n: number|undefined = undefined;
let texto: string = null;

let hola;
console.log(hola);