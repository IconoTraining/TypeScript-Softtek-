// boolean
var soltero = true;
var trabajador; // undefined
var activo = true; // No se recomienda declarar variables sin tipo
// number
var edad = 37;
var decimal = 6.2;
var hexadecimal = 0xfe124455;
var binario = 202;
var octal = 2263;
// string
var nombre = "Anabel";
var apellido = 'Vegas';
var email; // undefined
var nombreCompleto = "Me llamo ".concat(nombre, " ").concat(apellido);
console.log(nombreCompleto);
// any 
var algo = true;
algo = "Hola";
algo = 56;
var variable; // las variables sin tipo son de tipo any
// arrays
var numeros = [1, 2, 3, 4, 5, 6];
var numeros2 = [1, 2, 3, 4, 5, 6];
var numeros3 = [1, 2, 3, 4, 5, 6];
var vocales = ['a', 'e', 'i', 'o', 'u'];
// vocales.push(7);    error, no puedo agregar un numero a un array de texto
// tuplas
var producto = ["Melocotones", 2.75];
var producto2 = ["Melocotones", 2.75];
console.log("Fruta: " + producto2[0]);
console.log("Precio: " + producto2[1]);
// enum
//enum PuntoCardinal{NORTE, SUR, ESTE, OESTE};
//enum PuntoCardinal{NORTE=1, SUR, ESTE, OESTE};
var PuntoCardinal;
(function (PuntoCardinal) {
    PuntoCardinal[PuntoCardinal["NORTE"] = 2] = "NORTE";
    PuntoCardinal[PuntoCardinal["SUR"] = 4] = "SUR";
    PuntoCardinal[PuntoCardinal["ESTE"] = 6] = "ESTE";
    PuntoCardinal[PuntoCardinal["OESTE"] = 8] = "OESTE";
})(PuntoCardinal || (PuntoCardinal = {}));
;
var punto = PuntoCardinal.OESTE;
console.log(punto);
console.log(PuntoCardinal[6]); // ESTE
console.log(PuntoCardinal[5]); // undefined
// void
function mostrarInfo() {
    alert("Hola, me llamo ".concat(nombre, " ").concat(apellido, " y tengo ").concat(edad));
}
mostrarInfo();
// aserciones -> assertion
var num1 = 5;
var num2 = 6;
// let suma2: number = num1 + num2;   error
var suma = num1 + num2;
console.log(suma);
var cadena = "Hola, que tal?";
// let longitud = cadena.length;    ERROR
//let longitud: number = (<string>cadena).length;
var longitud = cadena.length;
console.log(longitud);
// null y undefined
// en tsconfig.json   ->   "strictNullChecks": false
var n = undefined;
var texto = null;
var hola;
console.log(hola);
