function listar(){
    let url = "https://pokeapi.co/api/v2/pokemon";

    // lanzo la peticion
    let promesa = fetch(url);  

    // la respuesta que recibo es correcta
    promesa.then(async (resultado) => {
        let data = await resultado.json();
        console.log(data.results);
        let pokemons = data.results;

        let lista = document.createElement('ul');
        for(let poke of pokemons){
            let item = document.createElement('li');
            item.textContent = poke.name;
            // otra opcion
            //let nombre = document.createTextNode(poke.name);
            //item.appendChild(nombre);
            lista.appendChild(item);
            
        }

        document.body.appendChild(lista);
    });

    // lo que recibo es un error
    promesa.catch(error => console.log(error));
}

function buscar(){
    let nombrePokemon = pokeTxt.value;
    let url = "https://pokeapi.co/api/v2/pokemon/" + nombrePokemon;

    fetch(url)
        .then(async (response) => {
            let datos = await response.json();
            console.log(datos);
            let objeto = datos;
            
            let seccion = document.querySelector("#resultado");
            seccion?.innerHTML = "<b>Datos del pokemon: " + nombrePokemon + "</b>";
            seccion?.innerHTML += "<br/>Peso: " + objeto.weight;
            seccion?.innerHTML += "<br/>Altura: " + objeto.height;
            seccion?.innerHTML += "<br/>Habilidades: ";
            seccion?.innerHTML += "<ol>";
            let habilidades = objeto.abilities;
            for(let habilidad of habilidades){
                seccion?.innerHTML += "<li>" + habilidad.ability.name + "</li>";
            }
            seccion?.innerHTML += "</ol>";
        })
        .catch(error => console.log(error));
}
