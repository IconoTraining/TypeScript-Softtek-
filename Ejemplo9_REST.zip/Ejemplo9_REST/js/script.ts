function listar(){
    var url = "https://pokeapi.co/api/v2/pokemon";

    // lanzo la peticion
    var promesa = fetch(url);  

    // la respuesta que recibo es correcta
    promesa.then(async (resultado) => {
        let data = await resultado.json();
        console.log(data.results);
    });

    // lo que recibo es un error
    promesa.catch(error => console.log(error));
}

listar();