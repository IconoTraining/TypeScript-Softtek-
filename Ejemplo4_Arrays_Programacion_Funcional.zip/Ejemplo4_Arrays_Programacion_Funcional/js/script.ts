enum Curso {PRIMERO=1, SEGUNDO, TERCERO};
type Alumno = {
    nombre:string,
    nota: number,
    curso: Curso
}

// Crear un array con 10 objetos de tipo Alumno
let alumnos: Array<Alumno> = [
    {nombre: 'Juan', nota: 8.2, curso: Curso.SEGUNDO},
    {nombre: 'Maria', nota: 5.1, curso: Curso.PRIMERO},
    {nombre: 'Luis', nota: 3.9, curso: Curso.SEGUNDO},
    {nombre: 'Jose', nota: 10, curso: Curso.TERCERO},
    {nombre: 'Laura', nota: 7.2, curso: Curso.PRIMERO},
    {nombre: 'German', nota: 2.6, curso: Curso.TERCERO},
    {nombre: 'Sandra', nota: 9.3, curso: Curso.PRIMERO},
    {nombre: 'Manuel', nota: 10, curso: Curso.SEGUNDO},
    {nombre: 'Veronica', nota: 4.1, curso: Curso.TERCERO},
    {nombre: 'Sofia', nota: 7.3, curso: Curso.SEGUNDO}
];

/*****************************
 * Metodos para manejar Arrays
 *****************************/

// push -> añade un elemento al final del array
alumnos.push({nombre: 'Antonio', nota: 9.9, curso: Curso.TERCERO});

// unshift -> añade un elemento al inicio del array
alumnos.unshift({nombre: 'Jorge', nota: 10, curso: Curso.PRIMERO});

// pop -> elimina el ultimo elemento del array
alumnos.pop();

// shift -> elimina el primer elemento del array
alumnos.shift();

/*****************************
 * Recorrer Arrays
 *****************************/

// Recorrer un array con for of
for(let alum of alumnos){  // cada elemento del array
    console.log(alum);
}

// Recorrer un array con for in
for(let i in alumnos){  // cada indice el array
    console.log(alumnos[i]);
}

// Recorrer un array con for tradicional
for(let i = 0; i < alumnos.length; i++){ // cada indice el array
    console.log(alumnos[i]);
}

// Recorrer un array con forEach
alumnos.forEach((alum) => {
    console.log(alum.nombre);
});

/*****************************
 * Programacion funcional 
 *****************************/

// map  ->  modificar cada elemento del array
let alumnosMayusculas = alumnos.map(item => item.nombre.toUpperCase());
alumnosMayusculas.forEach((alum) => {
    console.log(alum);
});

// filter  -> filtrar una coleccion por una condicion
let suspensos = alumnos.filter(alum => alum.nota < 5);
suspensos.forEach((alum) => {
    console.log(alum);
});

// reduce  -> devolver un unico resultado
let suma = [1,5,9,2,5,8,9,4].reduce((acum, num) => acum + num );
console.log(suma);

// ERROR acum es de tipo Alumno
//let suma2 = alumnos.reduce((acum, alum) => acum.nota + alum.nota );  

let totalNotas = alumnos.reduce((acumulador, alumno) => { 
    return acumulador + alumno.nota; 
}, 0);  // El acumulador se inicia a 0 y toma el tipo number
console.log("Nota media: " + totalNotas/alumnos.length);

let nombresAlumnos = alumnos.reduce((acum, alum) => 
    acum + " " + alum.nombre
, "");  // acum es de tipo string y se inicia como cadena vacia
console.log(nombresAlumnos);
