var Curso;
(function (Curso) {
    Curso[Curso["PRIMERO"] = 1] = "PRIMERO";
    Curso[Curso["SEGUNDO"] = 2] = "SEGUNDO";
    Curso[Curso["TERCERO"] = 3] = "TERCERO";
})(Curso || (Curso = {}));
;
// Crear un array con 10 objetos de tipo Alumno
var alumnos = [
    { nombre: 'Juan', nota: 8.2, curso: Curso.SEGUNDO },
    { nombre: 'Maria', nota: 5.1, curso: Curso.PRIMERO },
    { nombre: 'Luis', nota: 3.9, curso: Curso.SEGUNDO },
    { nombre: 'Jose', nota: 10, curso: Curso.TERCERO },
    { nombre: 'Laura', nota: 7.2, curso: Curso.PRIMERO },
    { nombre: 'German', nota: 2.6, curso: Curso.TERCERO },
    { nombre: 'Sandra', nota: 9.3, curso: Curso.PRIMERO },
    { nombre: 'Manuel', nota: 10, curso: Curso.SEGUNDO },
    { nombre: 'Veronica', nota: 4.1, curso: Curso.TERCERO },
    { nombre: 'Sofia', nota: 7.3, curso: Curso.SEGUNDO }
];
/*****************************
 * Metodos para manejar Arrays
 *****************************/
// push -> añade un elemento al final del array
alumnos.push({ nombre: 'Antonio', nota: 9.9, curso: Curso.TERCERO });
// unshift -> añade un elemento al inicio del array
alumnos.unshift({ nombre: 'Jorge', nota: 10, curso: Curso.PRIMERO });
// pop -> elimina el ultimo elemento del array
alumnos.pop();
// shift -> elimina el primer elemento del array
alumnos.shift();
/*****************************
 * Recorrer Arrays
 *****************************/
// Recorrer un array con for of
for (var _i = 0, alumnos_1 = alumnos; _i < alumnos_1.length; _i++) { // cada elemento del array
    var alum = alumnos_1[_i];
    console.log(alum);
}
// Recorrer un array con for in
for (var i in alumnos) { // cada indice el array
    console.log(alumnos[i]);
}
// Recorrer un array con for tradicional
for (var i = 0; i < alumnos.length; i++) { // cada indice el array
    console.log(alumnos[i]);
}
// Recorrer un array con forEach
alumnos.forEach(function (alum) {
    console.log(alum.nombre);
});
/*****************************
 * Programacion funcional
 *****************************/
// map  ->  modificar cada elemento del array
var alumnosMayusculas = alumnos.map(function (item) { return item.nombre.toUpperCase(); });
alumnosMayusculas.forEach(function (alum) {
    console.log(alum);
});
// filter  -> filtrar una coleccion por una condicion
var suspensos = alumnos.filter(function (alum) { return alum.nota < 5; });
suspensos.forEach(function (alum) {
    console.log(alum);
});
// reduce  -> devolver un unico resultado
var suma = [1, 5, 9, 2, 5, 8, 9, 4].reduce(function (acum, num) { return acum + num; });
console.log(suma);
// ERROR acum es de tipo Alumno
//let suma2 = alumnos.reduce((acum, alum) => acum.nota + alum.nota );  
var totalNotas = alumnos.reduce(function (acumulador, alumno) {
    return acumulador + alumno.nota;
}, 0); // El acumulador se inicia a 0 y toma el tipo number
console.log("Nota media: " + totalNotas / alumnos.length);
var nombresAlumnos = alumnos.reduce(function (acum, alum) {
    return acum + " " + alum.nombre;
}, ""); // acum es de tipo string y se inicia como cadena vacia
console.log(nombresAlumnos);
