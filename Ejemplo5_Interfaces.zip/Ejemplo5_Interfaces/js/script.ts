// Crear una interface Producto
interface Producto{
    id: number,
    descripcion: string,
    precio: number,
    getDescripcion: () => string, 
    setDescripcion: (descripcion: string) => void
    //setDescripcion(descripcion: string)
}

let prod1: Producto = {
    id: 1,
    descripcion: "Pantalla",
    precio: 129.50,
    getDescripcion(): string{
        return this.descripcion;
    },
    setDescripcion(descripcion){
        this.descripcion = descripcion;
    }
}

console.log(prod1);
console.log(prod1.getDescripcion());
prod1.setDescripcion("Pantalla nueva");
console.log(prod1);


// Propiedades o metodos opcionales
interface Animal{
    especie?: string,  // propiedad es opcional
    lugar: string,
    edad: number,
    getEspecie?: () => string  // metodo es optativo
}

let perro: Animal = {
    edad: 2,
    lugar: 'China'
}

let elefante: Animal = {
    especie: 'Mamifero',
    edad: 5,
    lugar: 'Thailandia',
    getEspecie(): string{
        return this.especie
    }
}

console.log(perro);
console.log(elefante);


// Interface para implementar funciones
interface Numeros{
    (num1: number, num2: number): number
}

let sumar: Numeros = (a: number, b: number) => {
    return a + b;
}

let restar: Numeros = (a: number, b: number) => {
    return a - b;
}

let multiplicar: Numeros = (a: number, b: number) => {
    return a * b;
}

let dividir: Numeros = (a: number, b: number) => {
    return a / b;
}

console.log("Suma: " + sumar(7,3));
console.log("Resta: " + restar(7,3));
console.log("Multiplicacion: " + multiplicar(7,3));
console.log("Division: " + dividir(7,3));


// Implementar una interface en una clase
interface Persona{
    nombre: string,
    edad: number,
    saludar?: () => void;
}

class Alumno implements Persona{
    nombre: string;
    edad: number;
    nota: number;
    saludar() {
        console.log(`Me llamo ${this.nombre}, tengo ${this.edad} 
            años y mi nota es ${this.nota}`)
    }
}

let juan: Alumno = {
    nombre: 'Juan',
    edad: 27,
    nota: 7.5,
    saludar() {
        console.log(`Me llamo ${this.nombre}, tengo ${this.edad} 
            años y mi nota es ${this.nota}`)
    }
}

console.log(juan.saludar());