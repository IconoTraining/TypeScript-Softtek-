// Crear una interface Producto
interface Producto{
    id: number,
    descripcion: string,
    precio: number,
    getDescripcion: () => string, 
    setDescripcion: (descripcion: string) => void
    //setDescripcion(descripcion: string)
}

let prod1: Producto = {
    id: 1,
    descripcion: "Pantalla",
    precio: 129.50,
    getDescripcion(): string{
        return this.descripcion;
    },
    setDescripcion(descripcion){
        this.descripcion = descripcion;
    }
}

console.log(prod1);
console.log(prod1.getDescripcion());
prod1.setDescripcion("Pantalla nueva");
console.log(prod1);


