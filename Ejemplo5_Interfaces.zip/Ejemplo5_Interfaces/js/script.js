var prod1 = {
    id: 1,
    descripcion: "Pantalla",
    precio: 129.50,
    getDescripcion: function () {
        return this.descripcion;
    },
    setDescripcion: function (descripcion) {
        this.descripcion = descripcion;
    }
};
console.log(prod1);
console.log(prod1.getDescripcion());
prod1.setDescripcion("Pantalla nueva");
console.log(prod1);
var perro = {
    edad: 2,
    lugar: 'China'
};
var elefante = {
    especie: 'Mamifero',
    edad: 5,
    lugar: 'Thailandia',
    getEspecie: function () {
        return this.especie;
    }
};
console.log(perro);
console.log(elefante);
var sumar = function (a, b) {
    return a + b;
};
var restar = function (a, b) {
    return a - b;
};
var multiplicar = function (a, b) {
    return a * b;
};
var dividir = function (a, b) {
    return a / b;
};
console.log("Suma: " + sumar(7, 3));
console.log("Resta: " + restar(7, 3));
console.log("Multiplicacion: " + multiplicar(7, 3));
console.log("Division: " + dividir(7, 3));
var Alumno = /** @class */ (function () {
    function Alumno() {
    }
    Alumno.prototype.saludar = function () {
        console.log("Me llamo ".concat(this.nombre, ", tengo ").concat(this.edad, " \n            a\u00F1os y mi nota es ").concat(this.nota));
    };
    return Alumno;
}());
var juan = {
    nombre: 'Juan',
    edad: 27,
    nota: 7.5,
    saludar: function () {
        console.log("Me llamo ".concat(this.nombre, ", tengo ").concat(this.edad, " \n            a\u00F1os y mi nota es ").concat(this.nota));
    }
};
console.log(juan.saludar());
