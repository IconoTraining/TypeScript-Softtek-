var prod1 = {
    id: 1,
    descripcion: "Pantalla",
    precio: 129.50,
    getDescripcion: function () {
        return this.descripcion;
    },
    setDescripcion: function (descripcion) {
        this.descripcion = descripcion;
    }
};
console.log(prod1);
console.log(prod1.getDescripcion());
prod1.setDescripcion("Pantalla nueva");
console.log(prod1);
