// Desestructuracion de objetos
var persona = {
    nombre: 'Jose',
    edad: 42
};
var alias = persona.nombre, edad = persona.edad;
console.log(alias);
// console.log(nombre);   ERROR
console.log(persona.nombre);
// Desestructuracion de arrays
var nombres = ['Jose', 'Pedro', 'Laura'];
var n1 = nombres[0], n2 = nombres[1], n3 = nombres[2];
console.log(n3);
// Si solo quiero desestructurar el tercer nombre
// let [name3] = nombres;  ERROR, coge el primer nombre
var name3 = nombres[2];
console.log(name3);
