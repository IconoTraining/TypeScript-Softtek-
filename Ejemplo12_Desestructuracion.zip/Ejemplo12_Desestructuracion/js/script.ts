// Desestructuracion de objetos
let persona = {
    nombre: 'Jose',
    edad: 42
};
let {nombre: alias, edad} = persona;
console.log(alias);
// console.log(nombre);   ERROR
console.log(persona.nombre);


// Desestructuracion de arrays
let nombres = ['Jose', 'Pedro', 'Laura'];
let [n1, n2, n3] = nombres;
console.log(n3);

// Si solo quiero desestructurar el tercer nombre
// let [name3] = nombres;  ERROR, coge el primer nombre

let [,,name3] = nombres;
console.log(name3);