/******************
 * Funcion generica
 ******************/
function mostrar<T> (dato: T){   // T puede ser cualquier tipo
    console.log(dato);
}

// Puedo llamar a la funcion con cualquier tipo de dato
mostrar(123);
mostrar(true);
mostrar("Buenas tardes");

/************************************
 * Ver el objeto de diferentes formas
 ************************************/
function funcionGenerica<T> (argumento:T){
    return argumento;
}

type Persona = {nombre: string, edad: number};
type Empleado = {nombre: string, edad: number, sueldo: number};

let empleado = {nombre: 'Jose', edad: 51, sueldo: 40000};

// Solo vemos el tipo Persona (nombre, edad)
funcionGenerica<Persona>(empleado).nombre 
funcionGenerica<Persona>(empleado).edad  

funcionGenerica<Empleado>(empleado).nombre
funcionGenerica<Empleado>(empleado).edad
funcionGenerica<Empleado>(empleado).sueldo


/******************
 * Arrays genericos
 ******************/
let numeros: Array<number> = [1,2,3,4,5,6];
numeros.push(7); 
// numeros.push("Hola");   ERROR, solo permite numeros

let nombres1: string[] = ["Jose", "Ana", "Luis", "Maria"];
let nombres2: Array<string> = ["Jose", "Ana", "Luis", "Maria"];
// nombres2.push(1); ERROR, solo permite cadenas de texto



/**********************
 * Clases con genericos
 **********************/
class Prueba<T extends number|string>{ // acepta number o string
    prop1: T;
    prop2: T;
}

let prueba1 = new Prueba();
prueba1.prop1 = "Hola";
prueba1.prop2 = 45;

let prueba2 = new Prueba<number>();  // El tipo de dato es number
// y las propiedades tambien seran de tipo number
prueba2.prop1 = 78;
//prueba2.prop2 = "Hola";  ERROR, solo acepta numeros

let prueba3 = new Prueba<string>();
prueba3.prop1 = "Hola";
// prueba3.prop2 = 74;  ERROR, solo acepta texto