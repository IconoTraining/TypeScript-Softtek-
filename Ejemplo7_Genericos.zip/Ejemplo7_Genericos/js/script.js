/******************
 * Funcion generica
 ******************/
function mostrar(dato) {
    console.log(dato);
}
// Puedo llamar a la funcion con cualquier tipo de dato
mostrar(123);
mostrar(true);
mostrar("Buenas tardes");
/************************************
 * Ver el objeto de diferentes formas
 ************************************/
function funcionGenerica(argumento) {
    return argumento;
}
var empleado = { nombre: 'Jose', edad: 51, sueldo: 40000 };
// Solo vemos el tipo Persona (nombre, edad)
funcionGenerica(empleado).nombre;
funcionGenerica(empleado).edad;
funcionGenerica(empleado).nombre;
funcionGenerica(empleado).edad;
funcionGenerica(empleado).sueldo;
/******************
 * Arrays genericos
 ******************/
var numeros = [1, 2, 3, 4, 5, 6];
numeros.push(7);
// numeros.push("Hola");   ERROR, solo permite numeros
var nombres1 = ["Jose", "Ana", "Luis", "Maria"];
var nombres2 = ["Jose", "Ana", "Luis", "Maria"];
// nombres2.push(1); ERROR, solo permite cadenas de texto
/**********************
 * Clases con genericos
 **********************/
var Prueba = /** @class */ (function () {
    function Prueba() {
    }
    return Prueba;
}());
var prueba1 = new Prueba();
prueba1.prop1 = "Hola";
prueba1.prop2 = 45;
var prueba2 = new Prueba(); // El tipo de dato es number
// y las propiedades tambien seran de tipo number
prueba2.prop1 = 78;
//prueba2.prop2 = "Hola";  ERROR, solo acepta numeros
var prueba3 = new Prueba();
prueba3.prop1 = "Hola";
// prueba3.prop2 = 74;  ERROR, solo acepta texto
