abstract class Figura{
    private _x: number;
    private _y: number;

    private static _contador: number = 0;

    constructor(x:number, y:number){
        this._x = x;
        this._y = y;
        Figura._contador++;
    }

    static getContador(): number{
        return Figura._contador;
    }

    abstract area(): number;

    posicion(): string{
        return `[${this._x},${this._y}]`;
    }

    getX(): number{
        return this._x;
    }

    setX(x: number){
        this._x = x;
    }

    getY(): number{
        return this._y;
    }

    setY(y: number){
        this._y = y;
    }
}

class Circulo extends Figura{
    private _radio: number;

    constructor(x: number, y: number, radio: number){
        super(x, y);  // Invocar al constructor de la superclase
        this._radio = radio;
    }

    area(): number{
        return Math.PI * Math.pow(this._radio, 2);
    }

    getRadio(): number{
        return this._radio;
    }

    setRadio(radio: number){
        this._radio = radio;
    }
}

class Rectangulo extends Figura{
    private _base: number;
    private _altura: number;

    constructor(x: number, y: number, base: number, altura: number){
        super(x,y);  // Invocamos al constructor de la superclase
        this._base = base;
        this._altura = altura;
    }

    area(): number{
        return this._base * this._altura;
    }

    getBase(): number{
        return this._base;
    }

    setBase(base: number){
        this._base = base;
    }

    getAltura(): number{
        return this._altura;
    }

    setAltura(altura: number){
        this._altura = altura;
    }
}

let circulo: Circulo = new Circulo(10, 20, 75);
console.log("Posicion: " + circulo.posicion());
console.log("Area: " + circulo.area());

let rectangulo: Rectangulo = new Rectangulo(30, 40, 100, 50);
console.log("Posicion: " + rectangulo.posicion());
console.log("Area: " + rectangulo.area());

console.log("Figuras creadas: " + Figura.getContador());