var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Figura = /** @class */ (function () {
    function Figura(x, y) {
        this._x = x;
        this._y = y;
        Figura._contador++;
    }
    Figura.getContador = function () {
        return Figura._contador;
    };
    Figura.prototype.posicion = function () {
        return "[".concat(this._x, ",").concat(this._y, "]");
    };
    Figura.prototype.getX = function () {
        return this._x;
    };
    Figura.prototype.setX = function (x) {
        this._x = x;
    };
    Figura.prototype.getY = function () {
        return this._y;
    };
    Figura.prototype.setY = function (y) {
        this._y = y;
    };
    Figura._contador = 0;
    return Figura;
}());
var Circulo = /** @class */ (function (_super) {
    __extends(Circulo, _super);
    function Circulo(x, y, radio) {
        var _this = _super.call(this, x, y) || this;
        _this._radio = radio;
        return _this;
    }
    Circulo.prototype.area = function () {
        return Math.PI * Math.pow(this._radio, 2);
    };
    Circulo.prototype.getRadio = function () {
        return this._radio;
    };
    Circulo.prototype.setRadio = function (radio) {
        this._radio = radio;
    };
    return Circulo;
}(Figura));
var Rectangulo = /** @class */ (function (_super) {
    __extends(Rectangulo, _super);
    function Rectangulo(x, y, base, altura) {
        var _this = _super.call(this, x, y) || this;
        _this._base = base;
        _this._altura = altura;
        return _this;
    }
    Rectangulo.prototype.area = function () {
        return this._base * this._altura;
    };
    Rectangulo.prototype.getBase = function () {
        return this._base;
    };
    Rectangulo.prototype.setBase = function (base) {
        this._base = base;
    };
    Rectangulo.prototype.getAltura = function () {
        return this._altura;
    };
    Rectangulo.prototype.setAltura = function (altura) {
        this._altura = altura;
    };
    return Rectangulo;
}(Figura));
var circulo = new Circulo(10, 20, 75);
console.log("Posicion: " + circulo.posicion());
console.log("Area: " + circulo.area());
var rectangulo = new Rectangulo(30, 40, 100, 50);
console.log("Posicion: " + rectangulo.posicion());
console.log("Area: " + rectangulo.area());
console.log("Figuras creadas: " + Figura.getContador());
