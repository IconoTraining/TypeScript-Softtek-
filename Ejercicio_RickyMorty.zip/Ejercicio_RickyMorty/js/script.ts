function mostrar(){
    fetch("https://rickandmortyapi.com/api/character")
        .then(async (response) => {
            let datos = await response.json();
            console.log(datos.results);
            let personajes = datos.results;

            // Crear una tabla
            let tabla = document.createElement('table');

            // Crear la fila de encabezados
            let fila = document.createElement('tr');
            let colNombre = document.createElement('th');
            colNombre.textContent = 'Nombre';
            fila.appendChild(colNombre);
            let colSexo = document.createElement('th');
            colSexo.textContent = 'Sexo';
            fila.appendChild(colSexo);
            let colEspecie = document.createElement('th');
            colEspecie.textContent = 'Especie';
            fila.appendChild(colEspecie);
            let colEstado = document.createElement('th');
            colEstado.textContent = 'Estado';
            fila.appendChild(colEstado);
            let colCreado = document.createElement('th');
            colCreado.textContent = 'Creado';
            fila.appendChild(colCreado);
            let colImagen = document.createElement('th');
            colImagen.textContent = 'Imagen';
            fila.appendChild(colImagen);

            // Agregar la fila a la tabla
            tabla.appendChild(fila);

            // Recorrer el array de los personajes y por cada
            // uno de ellos creamos una fila en la tabla
            for(let personaje of personajes){
                fila = document.createElement('tr');
                colNombre = document.createElement('td');
                colNombre.textContent = personaje.name;
                fila.appendChild(colNombre);
                colSexo = document.createElement('td');
                colSexo.textContent = personaje.gender;
                fila.appendChild(colSexo);
                colEspecie = document.createElement('td');
                colEspecie.textContent = personaje.species;
                fila.appendChild(colEspecie);
                colEstado = document.createElement('td');
                colEstado.textContent = personaje.status;
                fila.appendChild(colEstado);
                colCreado = document.createElement('td');
                colCreado.textContent = personaje.created;
                fila.appendChild(colCreado);
                colImagen = document.createElement('td');
                let imagen = document.createElement('img');
                imagen.setAttribute('src', personaje.image);
                colImagen.appendChild(imagen);
                fila.appendChild(colImagen);

                tabla.appendChild(fila);
            }

            // Agregar la tabla al body
            document.body.appendChild(tabla);
        })
        .catch(error => console.log(error));
}