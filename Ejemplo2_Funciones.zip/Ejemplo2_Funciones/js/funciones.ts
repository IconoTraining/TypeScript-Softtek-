// Funciones basicas
function saludar(nombre:string): void{
    alert("Hola " + nombre);
}

function sumar(num1:number, num2:number): number{
    return num1 + num2;
}


// Parametros opcionales =>   parametro?
function mostrar(nombre:string, apellido?:string): string{
    if (apellido){
        return `Me llamo ${nombre} ${apellido}`;
    } else {
        return `Me llamo ${nombre}`;
    }
}


// Parametros por defecto
function datos(nombre: string, soltero:boolean = true): string{
    if (soltero){
        return `${nombre} esta solter@`;
    } else {
        return `${nombre} no esta solter@`;
    }
}


// Numero variable de argumentos
function sumarNumeros(...numeros: number[]): number{
    let resultado: number = 0;
    for(let num of numeros){
        resultado += num;
    }
    return resultado;
}


// Ejercicio:
// funcion concatenar que reciba un numero variable de palabras y las devuelva
// unidas por un "-".
// Añadir a la funcion un parametro defecto que seria el caracter de separacion
function concatenar(separador:string = "-", ...palabras: string[] ): string{
    return palabras.join(separador);   
}


// Invocar a las funciones
saludar("Pepito");
console.log("Suma: " + sumar(8,2));
console.log(mostrar("Pepito"));
console.log(mostrar("Pepito", "Perez"));
console.log(datos("Maria"));
console.log(datos("Eva", false));
console.log(datos("Susana", true));
console.log("Suma: " + sumarNumeros());
console.log("Suma: " + sumarNumeros(7));
console.log("Suma: " + sumarNumeros(7,3));
console.log("Suma: " + sumarNumeros(7,3,8,1,4,8));
console.log(concatenar(undefined, "Maria", "Eva", "Susana"));
console.log(concatenar("|", "Maria", "Eva", "Susana"));