// Funciones basicas
function saludar(nombre:string):void{
    alert("Hola");
}

function sumar(num1:number, num2:number): number{
    return num1 + num2;
}


// Parametros opcionales
function mostrar(nombre:string, apellido?:string): string{
    if (apellido){
        return `Me llamo ${nombre} ${apellido}`;
    } else {
        return `Me llamo ${nombre}`;
    }
}

// Numero variable de argumentos




// Invocar a las funciones
saludar("Pepito");
console.log("Suma: " + sumar(8,2));
console.log(mostrar("Pepito"));
console.log(mostrar("Pepito", "Perez"));