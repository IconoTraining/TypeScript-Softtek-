// Funciones basicas
function saludar(nombre) {
    alert("Hola " + nombre);
}
function sumar(num1, num2) {
    return num1 + num2;
}
// Parametros opcionales =>   parametro?
function mostrar(nombre, apellido) {
    if (apellido) {
        return "Me llamo ".concat(nombre, " ").concat(apellido);
    }
    else {
        return "Me llamo ".concat(nombre);
    }
}
// Parametros por defecto
function datos(nombre, soltero) {
    if (soltero === void 0) { soltero = true; }
    if (soltero) {
        return "".concat(nombre, " esta solter@");
    }
    else {
        return "".concat(nombre, " no esta solter@");
    }
}
// Numero variable de argumentos
function sumarNumeros() {
    var numeros = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        numeros[_i] = arguments[_i];
    }
    var resultado = 0;
    for (var _a = 0, numeros_1 = numeros; _a < numeros_1.length; _a++) {
        var num = numeros_1[_a];
        resultado += num;
    }
    return resultado;
}
// Ejercicio:
// funcion concatenar que reciba un numero variable de palabras y las devuelva
// unidas por un "-".
// Añadir a la funcion un parametro defecto que seria el caracter de separacion
function concatenar(separador) {
    if (separador === void 0) { separador = "-"; }
    var palabras = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        palabras[_i - 1] = arguments[_i];
    }
    return palabras.join(separador);
}
// Invocar a las funciones
saludar("Pepito");
console.log("Suma: " + sumar(8, 2));
console.log(mostrar("Pepito"));
console.log(mostrar("Pepito", "Perez"));
console.log(datos("Maria"));
console.log(datos("Eva", false));
console.log(datos("Susana", true));
console.log("Suma: " + sumarNumeros());
console.log("Suma: " + sumarNumeros(7));
console.log("Suma: " + sumarNumeros(7, 3));
console.log("Suma: " + sumarNumeros(7, 3, 8, 1, 4, 8));
console.log(concatenar(undefined, "Maria", "Eva", "Susana"));
console.log(concatenar("|", "Maria", "Eva", "Susana"));
