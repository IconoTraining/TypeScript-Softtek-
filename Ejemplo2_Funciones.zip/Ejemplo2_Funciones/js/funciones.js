// Funciones basicas
function saludar(nombre) {
    alert("Hola");
}
function sumar(num1, num2) {
    return num1 + num2;
}
// Parametros opcionales
function mostrar(nombre, apellido) {
    if (apellido) {
        return "Me llamo ".concat(nombre, " ").concat(apellido);
    }
    else {
        return "Me llamo ".concat(nombre);
    }
}
// Numero variable de argumentos
// Invocar a las funciones
saludar("Pepito");
console.log("Suma: " + sumar(8, 2));
console.log(mostrar("Pepito"));
console.log(mostrar("Pepito", "Perez"));
