function mostrarConsola(constructor: Function){
    console.log(constructor);
    console.log("Alumno creado");
}

function mostrarAlert(valor: boolean): Function{
    if (valor == true){
        alert("Alumno creado");
        return mostrarConsola;
    } else {
        return () => {};
    }
}

@mostrarAlert(true)
@mostrarConsola
class Alumno{
    nombre: string;
    nota: number;

    constructor(nombre: string, nota: number){
        this.nombre = nombre;
        this.nota = nota;
    }
}

let maria: Alumno = new Alumno("Maria", 7.4);