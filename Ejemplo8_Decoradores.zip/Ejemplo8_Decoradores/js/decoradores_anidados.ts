function imprimible(constructor: Function){
    constructor.prototype.imprimir = function(){
        console.log(this);
    }
}

function saludo(constructor: Function){
    constructor.prototype.saludar = function(){
        console.log("Hola, que tal?");
    }
}

@imprimible
@saludo
class Persona{
    nombre: string;

    constructor(nombre: string){
        this.nombre = nombre;
    }
}

let persona: Persona = new Persona("Jose");
// Metodo del decorador imprimible
(<any>persona).imprimir();

// Metodo del decorador saludo
(<any>persona).saludar();