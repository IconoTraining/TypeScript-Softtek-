/*function editable(valor: boolean){
    return function(target: any, nombrePropiedad:string){
        let descriptor: PropertyDescriptor = {
            writable: valor
        }
        return descriptor;
    }
}*/
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
function editable(valor) {
    return function (target, key) {
        Object.defineProperty(target, key, {
            writable: valor
        });
    };
}
function ReadOnly(target, key) {
    Object.defineProperty(target, key, { writable: false });
}
var Producto = /** @class */ (function () {
    function Producto(id, descripcion, precio) {
        this.id = id;
        this.descripcion = descripcion;
        this.precio = precio;
    }
    Producto.prototype.mostrar = function () {
        return "ID: ".concat(this.id, ", Descripcion: ").concat(this.descripcion, ",\n            Precio: ").concat(this.precio);
    };
    __decorate([
        editable(true)
        //@ReadOnly
    ], Producto.prototype, "id");
    return Producto;
}());
var producto = new Producto(1, "Pantalla", 125);
producto.id = 6;
console.log(producto.mostrar());
