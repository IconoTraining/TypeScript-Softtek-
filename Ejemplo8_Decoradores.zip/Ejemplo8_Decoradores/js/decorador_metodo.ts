function log(){
    return function(target: any, key: string){
        console.log("Metodo invocado");
    }
}


class Ejemplo{

    @log()
    miMetodo(){
        alert("Hola");
    }
}

let prueba: Ejemplo = new Ejemplo();
prueba.miMetodo();