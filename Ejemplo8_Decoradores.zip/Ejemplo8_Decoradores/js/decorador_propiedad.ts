// En funcion del valor recibido, la propiedad se puede escribir o no.
function editable(valor:boolean) {
    return function (target: any, key: string) {  
        Object.defineProperty(target, key, {
            writable: valor
        });
    }
}

// La propiedad nunca se puede escribir
function ReadOnly(target: any, key: string) {  
	Object.defineProperty(target, key, { writable: false });
}


class Producto{

    @editable(true)
    //@ReadOnly
    id: number;

    descripcion: string;
    precio: number;

    constructor(id: number, descripcion: string, precio: number){
        this.id = id;
        this.descripcion = descripcion;
        this.precio = precio;
    }

    mostrar(){
        return `ID: ${this.id}, Descripcion: ${this.descripcion},
            Precio: ${this.precio}`;
    }
}

let producto: Producto = new Producto(1, "Pantalla", 125);
producto.id = 6;
console.log(producto.mostrar());