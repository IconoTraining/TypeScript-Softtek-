function parametro(target: any, metodo: string, index: number){
    console.log("Posicion: " + index);
    console.log("Metodo: " + metodo);
    console.log(target);
}


class Hola{

    saludar(nombre: string, @parametro apellido: string ){
        alert("Hola " + nombre + " " + apellido);
    }
}