/*
    Typescript tiene 3 modificadores de acceso:
    public -> se tiene acceso total
    private -> solo se puede acceder desde dentro de la clase
    protected -> se accede desde dentro de la clase y sus subclases
*/
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
// public
var Persona = /** @class */ (function () {
    function Persona() {
    }
    return Persona;
}());
var persona = new Persona();
persona.nombre = 'German';
persona.edad = 52;
console.log(persona);
// private
var Fecha = /** @class */ (function () {
    function Fecha() {
    }
    Fecha.prototype.setDia = function (dia) {
        this.dia = dia;
    };
    Fecha.prototype.setMes = function (mes) {
        this.mes = mes;
    };
    Fecha.prototype.setAnyo = function (anyo) {
        this.anyo = anyo;
    };
    return Fecha;
}());
var fecha = new Fecha();
// fecha.dia = 30;  ERROR de acceso
fecha.setDia(30);
console.log(fecha);
// protected
// crear la clase Empleado con private numEmpleado,public nombre y protected sueldo
// crear la clase Jefe que herede de Empleado con propiedad public bonus
var Empleado = /** @class */ (function () {
    function Empleado() {
    }
    Empleado.prototype.setNumEmpleado = function (numEmpleado) {
        this.numEmpleado = numEmpleado;
    };
    Empleado.prototype.getNumEmpleado = function () {
        return this.numEmpleado;
    };
    return Empleado;
}());
var Jefe = /** @class */ (function (_super) {
    __extends(Jefe, _super);
    function Jefe() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Jefe.prototype.setSueldo = function (sueldo) {
        // Desde la subclase tengo acceso a los recursos protected
        this.sueldo = sueldo;
    };
    Jefe.prototype.getSueldo = function () {
        return this.sueldo;
    };
    return Jefe;
}(Empleado));
// crear la instancia de Jefe
var jefe = new Jefe();
// jefe.numEmpleado = 1;   ERROR, es private y no tengo acceso
jefe.setNumEmpleado(1);
jefe.nombre = 'Pedro';
jefe.bonus = 12000;
// jefe.sueldo = 50000;  ERROR, es protected y no tengo acceso
jefe.setSueldo(50000);
console.log(jefe);
console.log(jefe.getSueldo());
console.log(jefe.getNumEmpleado());
