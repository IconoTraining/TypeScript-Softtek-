/*
    Typescript tiene 3 modificadores de acceso:
    public -> se tiene acceso total
    private -> solo se puede acceder desde dentro de la clase
    protected -> se accede desde dentro de la clase y sus subclases
*/

// public
class Persona{
    public nombre: string;
    edad: number;   // tambien es public
}

let persona = new Persona();
persona.nombre = 'German';
persona.edad = 52;
console.log(persona);


// private
class Fecha{
    private dia: number;
    private mes: number;
    private anyo: number;

    public setDia(dia: number){
        this.dia = dia;
    }

    public setMes(mes: number){
        this.mes = mes;
    }

    public setAnyo(anyo: number){
        this.anyo = anyo;
    }
}

let fecha = new Fecha();
// fecha.dia = 30;  ERROR de acceso
fecha.setDia(30);
console.log(fecha);

// protected
// crear la clase Empleado con private numEmpleado,public nombre y protected sueldo
// crear la clase Jefe que herede de Empleado con propiedad public bonus
class Empleado{
    private numEmpleado: number;
    public nombre: string;
    protected sueldo: number;

    setNumEmpleado(numEmpleado: number){
        this.numEmpleado = numEmpleado;
    }

    getNumEmpleado(){
        return this.numEmpleado;
    }
}

class Jefe extends Empleado{
    public bonus: number;

    setSueldo(sueldo: number){
        // Desde la subclase tengo acceso a los recursos protected
        this.sueldo = sueldo;  
    }

    getSueldo(){
        return this.sueldo;
    }

}

// crear la instancia de Jefe
let jefe: Jefe = new Jefe();
// jefe.numEmpleado = 1;   ERROR, es private y no tengo acceso
jefe.setNumEmpleado(1);
jefe.nombre = 'Pedro';
jefe.bonus = 12000;
// jefe.sueldo = 50000;  ERROR, es protected y no tengo acceso
jefe.setSueldo(50000);
console.log(jefe);
console.log(jefe.getSueldo());
console.log(jefe.getNumEmpleado());