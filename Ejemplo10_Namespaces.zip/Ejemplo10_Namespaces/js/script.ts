
// importar el namespace Utilitario que esta en la carpeta util

/// <reference path="util/textos.ts" />
/// <reference path="util/numeros.ts" />
/// <reference path="util/persona.ts" />

console.log(Utilitario.numCaracteres("Hola, que tal?"));
console.log(Utilitario.mayusculas("Esto es un texto en mayusculas"));
console.log(Utilitario.minusculas("Esto es un texto en minusculas"));

console.log(Utilitario.redondeoBaja(3.9));
console.log(Utilitario.redondeoMedio(3.4));
console.log(Utilitario.redondeoAlza(3.1));

let juan: Utilitario.Persona = new Utilitario.Persona("Juan", 27);
console.log(juan.mostrar());
