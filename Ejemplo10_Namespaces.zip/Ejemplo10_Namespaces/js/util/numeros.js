var Utilitario;
(function (Utilitario) {
    function redondeoBaja(numero) {
        return Math.floor(numero);
    }
    Utilitario.redondeoBaja = redondeoBaja;
    function redondeoMedio(numero) {
        return Math.round(numero);
    }
    Utilitario.redondeoMedio = redondeoMedio;
    function redondeoAlza(numero) {
        return Math.ceil(numero);
    }
    Utilitario.redondeoAlza = redondeoAlza;
})(Utilitario || (Utilitario = {}));
