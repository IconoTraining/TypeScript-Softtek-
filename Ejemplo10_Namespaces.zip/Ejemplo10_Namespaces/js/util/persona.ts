namespace Utilitario{

    export class Persona{
        nombre: string;
        edad: number;

        constructor(nombre: string, edad: number){
            this.nombre = nombre;
            this.edad = edad;
        }

        mostrar(): string{
            return `Nombre: ${this.nombre}, Edad: ${this.edad}`;
        }
    }
}