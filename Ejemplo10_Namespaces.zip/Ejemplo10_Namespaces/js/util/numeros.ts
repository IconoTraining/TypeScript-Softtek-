namespace Utilitario{

    export function redondeoBaja(numero: number): number{
        return Math.floor(numero);
    }

    export function redondeoMedio(numero: number): number{
        return Math.round(numero);
    }

    export function redondeoAlza(numero: number): number{
        return Math.ceil(numero);
    }

}