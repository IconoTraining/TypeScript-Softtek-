var Utilitario;
(function (Utilitario) {
    var Persona = /** @class */ (function () {
        function Persona(nombre, edad) {
            this.nombre = nombre;
            this.edad = edad;
        }
        Persona.prototype.mostrar = function () {
            return "Nombre: ".concat(this.nombre, ", Edad: ").concat(this.edad);
        };
        return Persona;
    }());
    Utilitario.Persona = Persona;
})(Utilitario || (Utilitario = {}));
