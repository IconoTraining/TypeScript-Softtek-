var Utilitario;
(function (Utilitario) {
    function numCaracteres(texto) {
        return texto.length;
    }
    Utilitario.numCaracteres = numCaracteres;
    function mayusculas(texto) {
        return texto.toUpperCase();
    }
    Utilitario.mayusculas = mayusculas;
    function minusculas(texto) {
        return texto.toLowerCase();
    }
    Utilitario.minusculas = minusculas;
})(Utilitario || (Utilitario = {}));
